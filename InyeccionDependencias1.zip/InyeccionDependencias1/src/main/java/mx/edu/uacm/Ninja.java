package mx.edu.uacm;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;

public class Ninja {
	
	//vamos a usar la parte de encapsulacion y el concepto de agregacion
		@Autowired //inyeccion de dependencias 
		@Qualifier("chacos")
		private Arma arma;
		
		@Value("pasar nivel")
		private String mision;
		/**
		 * @return the arma
		 */
		public Arma getArma() {
			return arma;
		}
		/**
		 * @param arma the arma to set
		 */
		public void setArma(Arma arma) {
			this.arma = arma;
		}
		/**
		 * @return the mision
		 */
		public String getMision() {
			return mision;
		}
		/**
		 * @param mision the mision to set
		 */
		public void setMision(String mision) {
			this.mision = mision;
		}
		

}
