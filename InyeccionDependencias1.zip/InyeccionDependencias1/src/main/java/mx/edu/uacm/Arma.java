package mx.edu.uacm;

public interface Arma {

}
